# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['portoapp',
 'portoapp._app_template.Admin',
 'portoapp._app_template.Data.Migrations',
 'portoapp._app_template.Models',
 'portoapp.config',
 'portoapp.management',
 'portoapp.management.commands']

package_data = \
{'': ['*'],
 'portoapp': ['_app_template/*',
              '_app_template/Actions/*',
              '_app_template/Tasks/*',
              '_app_template/UI/API/Controllers/*',
              '_app_template/UI/API/Routes/*',
              '_app_template/UI/API/Transformers/*']}

setup_kwargs = {
    'name': 'portoapp',
    'version': '0.1.0',
    'description': 'With protostart we can make porto containers in django project',
    'long_description': None,
    'author': 'BakdauletBolat',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
