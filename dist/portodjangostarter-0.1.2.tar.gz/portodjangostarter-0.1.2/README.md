# Porto container starter

This package uses to start a porto container

You can install this package very simple

## Installation


```bash
  pip install portodjangostarter
```

#### Add package to installed apps

```python
  INSTALLED_APPS = [
    ...
    'django.contrib.staticfiles',
    'portodjangostarter',
    ...
]
```

### And use it for happy 🚀
```python
   python manage.py startcontainer {{app_name}}
```

